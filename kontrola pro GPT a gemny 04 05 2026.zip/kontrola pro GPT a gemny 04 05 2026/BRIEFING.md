# TinyUseful — audit briefing pro GPT/Gemini
**Datum:** 2026-05-04 (večer, po 5-commit session)
**Live URL:** https://www.tinyuseful.app/
**Repo:** https://github.com/jetotakto/tinyuseful (Cloudflare Pages auto-deploy z main)

---

## TL;DR pro auditora

TinyUseful prošel 5-commit produktivní session. Hlavní výsledek: **statický kalkulátor web → reaktivní browser-based instrument** s decimal comma support, live calculation, copy result, traffic hygiene, security headers. Zachováno: brand identity (newspaper/architectural utility sheet), single-page architecture, anti-AI positioning, žádný framework, 1 deklarovaný AdSense slot.

**Hledáme váš pohled na:**
1. **Architektura `/js/helpers.js`** — DRY refactor, 4 utility funkce, event delegation. Je to dobré nebo přestřelené?
2. **Phase 51 live calc** — debounce 80ms, žádný flash, žádný count-up. Funguje to psychologicky správně?
3. **Calculate button retain decision** — zachován jako idempotent fallback. Správně, nebo by měl odejít?
4. **Cache + security headers** — dobře nastaveno, něco chybí?
5. **NaN edge case** — když uživatel smaže input, výsledek je `NaN`/`$NaN`/`NaN%`. Cosmetic problém. Phase 51b kandidát?
6. **Co dál** — Phase 53b (hybrid finance live calc) vs. Phase 54 (mobile compress) vs. něco co jsme přehlédli?

---

## Stav před session (2026-05-04 ráno)

- AdSense submitted (publisher pub-5316081427597729), pending review
- Web v0.7 + 49 phase commitů
- 11 tools live (8 Money + 3 Conversions): Percentage, Sales Tax, Tip, Discount, Mortgage, Loan, Compound Interest, Rent + Unit Converter, Date Calculator, Time Zone
- Cloudflare analytics (last 7 days):
  - Requests: 8.36k
  - Visits: 2.51k
  - Page views: 3.16k
  - Bandwidth: 73.7 MB
  - **4xx error rate: 11.48%** (exploit scans + missing assets)
  - **Cache hit rate: 8.51%** (low — žádné explicit cache rules)
- GSC (last 3 months): 0 clicks, 8 impressions, position 54.4
- Top traffic: USA 3.42k, CZ 2.29k, DE 518, NL 486

## Co se dnes commitnulo (5 commits)

| # | Commit | Phase | Co dělá |
|---|---|---|---|
| 1 | `0bd58ed` | Phase 50 | Decimal comma support — `parseLocaleNumber()` helper, 11 tool pages updated. CZ user může napsat `6,75` místo `6.75`. |
| 2 | `20a3f57` | Cleanup | `_preview-*.html` pattern do `.gitignore` + untrack 4 mockup files (původní chyba) |
| 3 | `b81ee54` | Phase 52 | Copy result button + `setOut()` centralizace. DOM API based (textContent), event delegation přes `[data-copy-result]`, smazáno 11 lokálních `setOut` definic. |
| 4 | `de53911` | Phase 53a | Traffic hygiene — `_headers` (cache rules + 3 security headers), favicon set (ICO, PNG 96, apple-touch 180, PWA 192/512), custom `site.webmanifest`. |
| 5 | (last) | Phase 51 + manifest fix | Live calculation pro 7 simple tools (debounce 80ms). Calculate button zachován jako fallback. Manifest extended o PWA 192/512. |

## Architektura helpers.js (po session)

```
/js/helpers.js (~110 řádků):
  window.parseLocaleNumber(raw)         — Phase 50, accept comma + spaces, NaN for invalid
  window.setOut(id, label, big, breakdown) — Phase 52, DOM API + auto-appends Copy button
  window.copyResultFromButton(btn)      — Phase 52, clipboard API + graceful fallback
  window.attachLiveCalc(selector, fn, wait=80) — Phase 51, debounced live update

  + 1 globální event listener na document pro [data-copy-result] (event delegation)

Loaded synchronously (no defer) before inline calc scripts.
Reason: inline `pctCalc()` calls `setOut()` synchronously during parsing,
defer would race-condition the helpers.js loading.
```

## 11 tool pages — současný flow

**7 simple tools (live calc, Phase 51):** Percentage, Sales Tax, Tip, Discount, Unit, Date, Time Zone
- Inline script má per-tool calc function (pctCalc, vatCalc, ...)
- Konec script tagu: `funcCalc(); attachLiveCalc('.tool-form', funcCalc);`
- Calculate button zachován v HTML

**4 hybrid finance (button only, Phase 53b plánováno):** Mortgage, Loan, Compound Interest, Rent
- Klasický pattern: form → Calculate → setOut
- **Phase 53b plán:** přidat live calc s validity guard (live update jen pokud všechna povinná pole valid)

## _headers strategie (Phase 53a)

```
/fonts/*                       max-age=31536000, immutable      (1 rok)
/og-image04.png                max-age=31536000, immutable      (1 rok)
/favicon.* + apple-touch + PWA max-age=604800                   (1 týden)
/site.webmanifest              max-age=604800                   (1 týden)
/style.css, /theme.js, /js/*   max-age=86400                    (1 den)
/robots, /sitemap, /ads.txt    max-age=86400                    (1 den)
/.well-known/*                 max-age=86400                    (1 den)
/*.html                        max-age=300                      (5 minut)

+ X-Content-Type-Options: nosniff
+ X-Frame-Options: SAMEORIGIN
+ Referrer-Policy: strict-origin-when-cross-origin
```

## Co je zachováno (záměrně)

- ✅ Brand identity: paper #FAF8F2 + ink #111 + red #C8102E akcent
- ✅ Architectural utility sheet aesthetic (Montserrat brand + Inter UI + JetBrains Mono technical)
- ✅ Anti-AI positioning ("No AI" v trust badges)
- ✅ Single-page architecture (žádný framework, žádný build step)
- ✅ Cloudflare Pages + GitHub jetotakto/tinyuseful auto-deploy
- ✅ 1 deklarovaný AdSense slot (placeholder 728×90)
- ✅ "Inputs stay in your browser" claim (precise post Phase 45A)
- ✅ Calculate button (jako idempotent fallback po Phase 51)

## Co je NOT touched (podle pravidla "počkat na AdSense decision")

- ❌ AdSense placeholder pořád placeholder (Phase 56 čeká na schválení)
- ❌ Hybrid finance tools live calc (Phase 53b)
- ❌ Mobile compression (Phase 54-55)
- ❌ Žádné nové tools (Flooring, Paint, ...)
- ❌ Žádný blog post
- ❌ Žádný Searchle / SearchGuess
- ❌ Žádný redesign brandu

## Známé pending issues

### 1. NaN cosmetic (low priority)
Když uživatel smaže input úplně během live calc, výsledek zobrazí `NaN`, `$NaN`, `NaN%` místo `—`. Default values jsou nastavené v inputs takže nastane jen pokud user cíleně smaže.

**Phase 51b candidate:** přidat NaN guard do `setOut`:
```js
const safeBig = (big === null || big === undefined || big === '' ||
                (typeof big === 'string' && big.includes('NaN'))) ? '—' : String(big);
```

### 2. Cache + 4xx measurement pending
Phase 53a deployed, ale Cloudflare analytics se aktualizuje s 24-72h delay. Pondělní rituál (~3 dny od teď) ověří fakticky:
- Cílový pokles 4xx z 11.48% na ~5-7%
- Cílový nárůst cache rate z 8.51% na 25-35%

### 3. Date Calculator jednou volá calc 2× při category change
V Unit Converter `onchange="unitUpdateOptions()"` na `unit-cat` dropdown volá `unitCalc` interně. Můj `attachLiveCalc` change handler taky zachytí change event a volá `unitCalc` znovu (po 80ms debounce). Takže 2 výpočty místo 1. Bezpečné (idempotent), jen mírně neefektivní. Negligible.

## Otázky pro auditora

### Architektura
- Je `/js/helpers.js` se 4 utility funkcemi správný kompromis mezi DRY a single-purpose? Nebo bychom měli rozdělit do 4 souborů?
- `window.X = function X(...)` pattern — best practice nebo overkill vs. implicit globals přes function declaration?
- Event delegation pro `[data-copy-result]` — skvělé, nebo bychom měli mít discrete listeners per page?

### UX
- Live calc bez visual feedback (žádný flash) — funguje psychologicky? Nebo by měl být jemný indicator že se počítalo?
- Calculate button retain — správně? Nebo zbytečný balast?
- Copy result text format `[label]: [big] — [breakdown]` — užitečný? Nebo by měl být jiný (např. JSON, CSV)?

### Performance
- Cache hit rate měřitelný impact po 24-72h. Co bychom měli dál sledovat?
- Pokud cache rate nestoupne výrazně, kde je další páka?

### SEO/AdSense
- 4xx 11.48% — co dál pokud po Phase 53a ještě > 7%?
- AdSense submission po 5 commitech ten samý den — risk že to zpomalí review? Nebo to nehraje roli?

### Co jsme přehlédli
- Něco co bys udělal jinak?
- Něco co jsme úplně vynechali?

---

## Příloha — soubory v této složce

```
BRIEFING.md                 ← tento dokument
src/                        ← snapshot produkčních souborů
  index.html                  homepage
  about.html, privacy.html, terms.html, 404.html  ← navigation pages
  style.css                   shared stylesheet
  theme.js                    light/dark mode toggle
  site.webmanifest            PWA manifest
  _headers                    Cloudflare cache rules
  robots.txt
  sitemap.xml
  ads.txt
  humans.txt
  js/
    helpers.js                ← KEY: shared utility functions
  percentage-calculator/index.html
  sales-tax-calculator/index.html
  tip-calculator/index.html
  discount-calculator/index.html
  mortgage-calculator/index.html
  loan-calculator/index.html
  compound-interest-calculator/index.html
  rent-affordability-calculator/index.html
  unit-converter/index.html
  date-calculator/index.html
  time-zone-converter/index.html
git_log.txt                 ← posledních ~30 commitů
```

## Jak audit pustit (instrukce pro Lukase do GPT/Gemini)

Pošli GPT/Gemini tento prompt:

> Jsi UX/architecture auditor. Mám statický web TinyUseful (calculators, anti-AI positioning, AdSense pending). Včera jsem udělal 5 produkčních commitů — viz BRIEFING.md (přiloženo). Zhodnoť architekturu `/js/helpers.js`, Phase 51 live calc UX rozhodnutí, cache + security headers nastavení, a doporuč co dál (Phase 53b vs 54 vs něco jiného). Buď konkrétní, ne generic.
